export class FilmModel{
    id: number;
    name: string;
    days: string[];
}